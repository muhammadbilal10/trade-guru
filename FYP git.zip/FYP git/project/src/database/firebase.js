// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAV6lZb3OAPV9_u59VMMEN241VYVYL0Vs0",
  authDomain: "project-5e91f.firebaseapp.com",
  projectId: "project-5e91f",
  storageBucket: "project-5e91f.appspot.com",
  messagingSenderId: "392232771839",
  appId: "1:392232771839:web:9636230747cdc70b782cca"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export default app;
