import React, { useState, useEffect } from 'react';
import { getFirestore, collection, getDocs } from 'firebase/firestore';
import app from "../../../database/firebase";
import { Link } from "react-router-dom";
import Sidenav from '../navbar/sidenav';
import Topnav from '../navbar/topnavbar';

const Approvals = () => {
    const [users, setUsers] = useState([]);
    const db = getFirestore(app);

    useEffect(() => {
        const fetchUsers = async () => {
            const usersCollection = collection(db, 'Users');
            const userData = await getDocs(usersCollection);
            setUsers(userData.docs.map(doc => ({ id: doc.id, ...doc.data() })));
        };

        fetchUsers();
    }, [db]);

    // The rest of your component logic

    // Make sure the return statement is inside the component function
    return (
        <div className="flex h-screen bg-gray-100 overflow-hidden">
            <Sidenav />
            <div className="flex-1 flex flex-col overflow-hidden">
                <Topnav />
                <main className="flex-1 overflow-x-hidden overflow-y-auto bg-gray-200">
                    <div className="container mx-auto px-6 py-8">
                        <h3 className="text-gray-700 text-3xl font-medium">Approvals</h3>
                        <div className="mt-8">
                            {users.map(user => (
                                <div key={user.id} className="flex justify-between items-center bg-white p-6 rounded-lg shadow-xs mb-6">
                                    <div>
                                        <p className="text-lg font-semibold text-gray-800">{user.name}</p>
                                        <p className="text-sm text-gray-600 mt-1">Status: {user.status}</p>
                                    </div>
                                    <div className="flex">
                                        <button className="text-white bg-green-500 hover:bg-green-600 px-4 py-2 rounded transition ease-in duration-200 focus:outline-none mr-2">
                                            Approve
                                        </button>
                                        <button className="text-white bg-red-500 hover:bg-red-600 px-4 py-2 rounded transition ease-in duration-200 focus:outline-none">
                                            Disapprove
                                        </button>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                </main>
            </div>
        </div>
    );
};

export default Approvals;
