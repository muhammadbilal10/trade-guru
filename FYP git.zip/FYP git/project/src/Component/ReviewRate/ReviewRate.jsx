import React, { useState } from 'react';

const courses = ['Course 1', 'Course 2', 'Course 3']; // Example courses
import Navbar from "../navbar/navbar";
const StarRating = ({ onRating }) => {
  const [rating, setRating] = useState(0);

  return (
    
    <div className="flex">
      {[...Array(5)].map((star, index) => {
        index += 1;
        return (
          <button
            type="button"
            key={index}
            className={`hover:text-yellow-600 ${index <= rating ? 'text-yellow-500' : 'text-gray-300'}`}
            onClick={() => { setRating(index); onRating(index); }}
          >
            <span className="text-2xl">&#9733;</span>
          </button>
        );
      })}
    </div>
  );
};

const ReviewRate = () => {
  const [course, setCourse] = useState('');
  const [review, setReview] = useState('');
  const [rating, setRating] = useState(0);

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log({ course, review, rating });
    // Handle submission logic here
  };

  return (
    <>
      <Navbar/>
    <div className="p-6 max-w-lg mx-auto bg-white rounded-xl shadow-md flex items-center space-x-4">
      <form onSubmit={handleSubmit} className="w-full">
        <h3 className="text-xl font-semibold text-gray-800 mb-4">Course Review</h3>
        <div className="mb-4">
          <label htmlFor="course" className="block text-gray-600 text-sm font-medium mb-2">
            Select Course
          </label>
          <select
            id="course"
            value={course}
            onChange={(e) => setCourse(e.target.value)}
            className="block w-full px-3 py-2 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
          >
            <option value="">Choose a course</option>
            {courses.map((course) => (
              <option key={course} value={course}>{course}</option>
            ))}
          </select>
        </div>

        <div className="mb-4">
          <label htmlFor="review" className="block text-gray-600 text-sm font-medium mb-2">
            Your Review
          </label>
          <textarea
            id="review"
            value={review}
            onChange={(e) => setReview(e.target.value)}
            className="block w-full px-3 py-2 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
            rows="4"
            placeholder="Write your review here..."
          ></textarea>
        </div>

        <div className="mb-6">
          <label className="block text-gray-600 text-sm font-medium mb-2">
            Your Rating
          </label>
          <StarRating onRating={(rate) => setRating(rate)} />
        </div>

        <button
          type="submit" 
          className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-2 px-4 rounded-md transition duration-300"
        >
          Submit Review
        </button>
      </form>
    </div>
    </>
  );
};

export default ReviewRate;
